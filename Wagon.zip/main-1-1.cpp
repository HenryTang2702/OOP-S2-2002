#include<iostream>
#include<string.h>
#include<string>
#include"Capybara.h"

using namespace std;

int main() {
    Capybara a;
    return 0;
}