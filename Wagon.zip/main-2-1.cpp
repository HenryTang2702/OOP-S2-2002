#include<iostream>
#include<string.h>
#include<string>
#include "Wagon.h"
#include "Capybara.h"

using namespace std;

int main() {
    Wagon a;
    return 0;
}