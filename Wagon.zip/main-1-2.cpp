#include<iostream>
#include<string.h>
#include<string>
#include "Person.h"

using namespace std;

int main() {
    Person a;

    return 0;
}