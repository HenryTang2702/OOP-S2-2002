#include<iostream>
#include<string.h>
#include<string>
#include "Person.h"
#include "Airplane.h"

using namespace std;

int main() {

    return 0;
}